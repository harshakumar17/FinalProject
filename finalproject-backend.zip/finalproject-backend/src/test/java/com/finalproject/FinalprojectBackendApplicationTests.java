package com.finalproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalprojectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
