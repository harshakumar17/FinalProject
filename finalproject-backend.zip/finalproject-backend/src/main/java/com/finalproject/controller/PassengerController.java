package com.finalproject.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finalproject.model.Passenger;
import com.finalproject.service.PassengerService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("api/passengers")
public class PassengerController {
	
	private PassengerService passengerService;

	public PassengerController(PassengerService passengerService) {
		super();
		this.passengerService = passengerService;
	}
	
	@PostMapping()
	public ResponseEntity<Passenger> savePassenger(@RequestBody Passenger passenger){
		return new ResponseEntity<Passenger>(passengerService.savePassenger(passenger),HttpStatus.CREATED);
	}
	
	@GetMapping
	public List<Passenger> getAllPassengers(){
		return passengerService.getAllPassengers();
	}
	
	@GetMapping("{pId}")
	public  ResponseEntity<Passenger> getPassengerById(@PathVariable("id") long pId){
		return new ResponseEntity<Passenger>(passengerService.getPassengerById(pId), HttpStatus.OK);
	}
	
	@PutMapping("{pId}")
	public ResponseEntity<Passenger> updatePassenger(@PathVariable("pId")long pId, @RequestBody Passenger passenger){
		return new ResponseEntity<Passenger>(passengerService.updatePassenger(passenger, pId),HttpStatus.OK);
	}
	
	@DeleteMapping("{pId}")
	public ResponseEntity<String> deletePassenger(@PathVariable("pId") long pId){
		passengerService.deletePassenger(pId);
		return new ResponseEntity<String>("Passenger deleted",HttpStatus.OK);
	}
	
}	
