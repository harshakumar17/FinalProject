package com.finalproject.controller;



import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finalproject.model.Admin;
import com.finalproject.service.AdminService;




@CrossOrigin(origins="http://localhost:4200")
@RestController //is controller which provides different end points to access the services 
//http://localhost:8089/api/admins/
@RequestMapping("/api/admins/")
public class AdminController {

	private AdminService adminService;

	public AdminController(AdminService adminService) {
		super();
		this.adminService = adminService;
	}
	//http://localhost:8089/api/admins
	@PostMapping
	public ResponseEntity<Admin> saveAdmin(@RequestBody Admin admin)
	{
		System.out.println(admin);
		return new ResponseEntity<Admin>(adminService.saveAdmin(admin),HttpStatus.CREATED);
	}
	//http://localhost:8089/api/admins
	@GetMapping
	public List<Admin> getAllAdmin()
	{
		return adminService.getAllAdmin();
	}
	//http://localhost:8089/api/admins/2
	@GetMapping("{aid}")
	public ResponseEntity<Admin> getAdminById(@PathVariable("aid") long adminId)
	{
		return new ResponseEntity<Admin>(adminService.getAdminById(adminId),HttpStatus.OK);
	}
	//http://localhost:8089/api/admins/2
	@PutMapping("{aid}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable("aid") long aid, @RequestBody Admin admin)
	{
		return new ResponseEntity<Admin> (adminService.updateAdmin(admin, aid),HttpStatus.OK);
	}
	//http://localhist:8089/api/admins/6
	@DeleteMapping("{aid}")
	public ResponseEntity<String> deleteAdmin(@PathVariable("aid") long aid)
	{
		adminService.deleteAdmin(aid);
		return new ResponseEntity<String>("Admin deleted successfully",HttpStatus.OK);
	}
}