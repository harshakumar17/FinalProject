package com.finalproject.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.finalproject.exception.ResourceNotFoundException;
import com.finalproject.model.Passenger;
import com.finalproject.repository.PassengerRepository;
import com.finalproject.service.PassengerService;

@Service
//@Transactional
public class PassengerServiceImpl implements PassengerService {

	private PassengerRepository passengerRepository;
	
//	@Autowired
	public PassengerServiceImpl(PassengerRepository passengerRepository) {
		super();
		this.passengerRepository = passengerRepository;
	}


	@Override
	public Passenger savePassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(passenger);
	}


	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return passengerRepository.findAll();
	}


	@Override
	public Passenger getPassengerById(long pId)
	{
		// TODO Auto-generated method stub
		Optional<Passenger> passenger = passengerRepository.findById(pId);
		if(passenger.isPresent()) {
			return passenger.get();
		} else {
			return null;
		}
			
	}


	@Override
	public void deletePassenger(long pId) {
		// TODO Auto-generated method stub
		passengerRepository.deleteById(pId);
		
	}


	@Override
	public Passenger updatePassenger(Passenger passenger, long pId) {
		// TODO Auto-generated method stub
		Passenger existingPassenger = passengerRepository.findById(pId).orElseThrow( () -> new ResourceNotFoundException("Passenger","pId",pId));
		existingPassenger.setFirstName(passenger.getFirstName());
		existingPassenger.setLastName(passenger.getLastName());
		passengerRepository.save(existingPassenger);
		return existingPassenger;
	}
	
	
	
	
}
