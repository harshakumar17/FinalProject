package com.finalproject.service;

import java.util.List;

import com.finalproject.model.Passenger;

public interface PassengerService {
	Passenger savePassenger(Passenger passenger);
	List<Passenger> getAllPassengers();
	Passenger getPassengerById(long pId);
	Passenger updatePassenger(Passenger passenger, long pId);
	void deletePassenger(long pId);
}
