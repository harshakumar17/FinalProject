package com.finalproject.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;

import com.finalproject.exception.ResourceNotFoundException;
import com.finalproject.model.Admin;
import com.finalproject.repository.AdminRepository;
import com.finalproject.service.AdminService;




@Service
public class AdminServiceImpl implements AdminService{
	
	private AdminRepository adminRepository;
	
	
	
	public AdminServiceImpl(AdminRepository adminRepository) {
		super();
		this.adminRepository = adminRepository;
	}



	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}



	@Override
	public List<Admin> getAllAdmin() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}



	@Override
	public Admin getAdminById(long aid) {
		
		return adminRepository.findById(aid).orElseThrow(()->new ResourceNotFoundException("Admin","Id",aid));
	}



	@Override
	public Admin updateAdmin(Admin admin, long aid) {
		// TODO Auto-generated method stub
		Admin existingAdmin=adminRepository.findById(aid).orElseThrow(()->new ResourceNotFoundException("Admin","Id",aid));
		existingAdmin.setFirstname(admin.getFirstname());
		existingAdmin.setLastname(admin.getLastname());
		existingAdmin.setEmail(admin.getEmail());
		adminRepository.save(existingAdmin);
		return existingAdmin;
	}



	@Override
	public void deleteAdmin(long aid) {
		// TODO Auto-generated method stub
		adminRepository.findById(aid).orElseThrow(()->new ResourceNotFoundException("Admin","Id",aid));
		adminRepository.deleteById(aid);
		
	}
	
}