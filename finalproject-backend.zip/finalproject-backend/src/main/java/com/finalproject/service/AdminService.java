package com.finalproject.service;

import java.util.List;

import com.finalproject.model.Admin;




public interface AdminService {
	Admin saveAdmin(Admin admin);
	List<Admin> getAllAdmin();
	Admin getAdminById(long aid);
	Admin updateAdmin(Admin admin, long aid);
	void deleteAdmin(long aid);
}