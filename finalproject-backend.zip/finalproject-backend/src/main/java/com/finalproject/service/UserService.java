package com.finalproject.service;

import java.util.List;

import com.finalproject.model.User;


public interface UserService {
	//User getUserByEmail(String email);
	User  saveUser(User user);
	List<User> getAllUser();
	User getUserById(long uid);
	User updateUser(User user, long uid);
	void deleteUser(long uid);
}